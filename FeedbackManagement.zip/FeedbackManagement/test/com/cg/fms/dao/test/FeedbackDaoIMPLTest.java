package com.cg.fms.dao.test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.fms.dao.FeedbackDaoIMPL;
import com.cg.fms.dao.IFeedbackDao;
import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.CourseFacultyMapBean;
import com.cg.fms.model.CourseMasterBean;
import com.cg.fms.model.FacultySkillMasterBean;
import com.cg.fms.model.LoginBean;
import com.cg.fms.model.TrainingProgramMaintain;
import com.cg.fms.model.feedbackBean;
import com.cg.fms.model.participantEnroll;
import com.cg.fms.model.viewFeedbackMaster;

public class FeedbackDaoIMPLTest {
	IFeedbackDao dao = null;

	@Before
	public void setUp() throws Exception {
		dao = new FeedbackDaoIMPL();
	}

	@After
	public void tearDown() throws Exception {
		dao = null;
	}
    @Test
	public void testLogin()
	{
		LoginBean lbean=new LoginBean("deepa","1234");
		try {
			String result = dao.checkRole(lbean);
			assertEquals("admin", result);
		} catch (FMSException e) {
			System.out.println(e.getMessage());
		}
	}
	@Test
	public void testInsertFacultySkill() {
		FacultySkillMasterBean fbean = new FacultySkillMasterBean("2009", "sql");
		try {
			int result = dao.insertFacultySkill(fbean);
			assertEquals(1, result);
		} catch (FMSException e) {
			System.out.println(e.getMessage());
		}
	}

	@Test
	public void testUpdateFacultySkillOper() {

		FacultySkillMasterBean fsbean = new FacultySkillMasterBean("2052",
				"jee");
		try {
			int result = dao.updateFacultySkillOper(fsbean);
			assertEquals(1, result);
		} catch (FMSException e) {
			System.out.println(e.getMessage());
		}
	}

	@Test
	public void testDeletefacultySkilloper() {
		try {
			int result = dao.deletefacultySkilloper("2000");
			assertEquals(1, result);
		} catch (FMSException e) {
			System.out.println(e.getMessage());
		}
	}

	@Test
	public void testViewAllFacultyDetails() {
		try {
			List<FacultySkillMasterBean> result = dao.viewAllFacultyDetails();
			boolean flag = result.isEmpty();
			assertFalse(flag);
		} catch (FMSException e) {
			System.out.println(e.getMessage());
		}
	}

	@Test
	public void testViewMapDetails() {
		try {
			List<CourseFacultyMapBean> result = dao.viewMapDetails();
			boolean flag = result.isEmpty();
			assertFalse(flag);
		} catch (FMSException e) {
			System.out.println(e.getMessage());
		}
	}

	@Test
	public void testInsertCourseDetails() {
		CourseMasterBean cbean = new CourseMasterBean("1004", "sql", "12");
		try {
			int result = dao.insertCourseDetails(cbean);
			assertEquals(1, result);
		} catch (FMSException e) {
			System.out.println(e.getMessage());
		}
	}

	@Test
	public void testUpdateCourseOper() {
		CourseMasterBean cupbean = new CourseMasterBean("1004", "java", "12");
		try {
			int result = dao.updateCourseOper(cupbean);
			assertEquals(1, result);
		} catch (FMSException e) {
			System.out.println(e.getMessage());
		}
	}

	@Test
	public void testDeleteCourseoper() {

		try {
			int result = dao.deleteCourseoper("1004");
			assertEquals(1, result);
		} catch (FMSException e) {
			System.out.println(e.getMessage());
		}
	}

	@Test
	public void testViewAllCourseDetails() {

		try {
			List<CourseMasterBean> result = dao.viewAllCourseDetails();
			boolean flag = result.isEmpty();
			assertFalse(flag);
		} catch (FMSException e) {
			System.out.println(e.getMessage());
		}

	}

	@Test
	public void testFetchingTrainingProgramDetails() {
		try {
			List<TrainingProgramMaintain> result = dao
					.fetchingTrainingProgramDetails();
			boolean flag = result.isEmpty();
			assertFalse(flag);
		} catch (FMSException e) {
			System.out.println(e.getMessage());
		}

	}

	@Test
	public void testInsertFeedback() {
		feedbackBean fbean = new feedbackBean("3000", "4002", "5", "5", "4",
				"3", "3", "good", "do well");
		try {
			int result = dao.insertFeedback(fbean);
			assertEquals(1, result);
		} catch (FMSException e) {
			System.out.println(e.getMessage());
		}
	}

	@Test
	public void testInsertParticipant() {
		participantEnroll pbean = new participantEnroll("3001", "4002");
		try {
			int result = dao.insertParticipant(pbean);
			assertEquals(1, result);
		} catch (FMSException e) {
			System.out.println(e.getMessage());
		}
	}

	@Test
	public void testViewAllFeedbackDetails() {
		try {
			List<viewFeedbackMaster> result = dao.viewAllFeedbackDetails();
			boolean flag = result.isEmpty();
			assertFalse(flag);
		} catch (FMSException e) {
			System.out.println(e.getMessage());
		}
	}

}
