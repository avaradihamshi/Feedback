package com.cg.fms.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cg.fms.exceptions.FMSException;

public class JdbcUtility {

	private static Connection connection=null;
	public static Connection getConnection() throws FMSException{

		Properties properties=new Properties();
		try {
			properties.load(new FileInputStream(new File("resources/jdbc.properties")));

			String driver =properties.getProperty("db.driver");
			String url =properties.getProperty("db.url");
			String username =properties.getProperty("db.username");
			String password =properties.getProperty("db.password");

			try {
				Class.forName(driver);
				try {
					connection =DriverManager.getConnection(url,username,password);
				} catch (SQLException e) {
					throw new FMSException("connection was not established");
				}
			} catch (ClassNotFoundException e) {
				throw new FMSException("unable to load the class....");

			}



		} catch (IOException e) {
			throw new FMSException("unable to read data from the File,Try again..");
		}
		return connection;

	}
	
	public static void closeConnection() throws FMSException
	{
		try {
			connection.close();
		} catch (SQLException e) {
			throw new FMSException("unable to close the connection");
		}
	}

}
