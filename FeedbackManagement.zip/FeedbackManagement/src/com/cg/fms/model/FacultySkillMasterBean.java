package com.cg.fms.model;

public class FacultySkillMasterBean {
	private String facultyId;
	private String facultySkillSet;
	

	public FacultySkillMasterBean(String facultyId, String facultySkillSet) {
		super();
		this.facultyId = facultyId;
		this.facultySkillSet = facultySkillSet;
	}

	@Override
	public String toString() {
		return "FacultySkillMasterBean [facultyId=" + facultyId
				+ ", facultySkillSet=" + facultySkillSet + "]";
	}

	public String getFacultyId() {
		return facultyId;
	}

	public FacultySkillMasterBean(String facultyId) {
		super();
		this.facultyId = facultyId;
	}

	public void setFacultyId(String facultyId) {
		this.facultyId = facultyId;
	}

	public String getFacultySkillSet() {
		return facultySkillSet;
	}

	public void setFacultySkillSet(String facultySkillSet) {
		this.facultySkillSet = facultySkillSet;
	}

	public FacultySkillMasterBean() {
	}

}
