package com.cg.fms.model;

public class CourseFacultyMapBean {
	private String courseId;
	private String courseName;
	private String noOfDays;
	private String facultyId;
	private String facultySkill;

	public CourseFacultyMapBean(String courseId, String courseName,
			String noOfDays, String facultyId, String facultySkill) {
		super();
		this.courseId = courseId;
		this.courseName = courseName;
		this.noOfDays = noOfDays;
		this.facultyId = facultyId;
		this.facultySkill = facultySkill;
	}

	public String getCourseId() {
		return courseId;
	}

	public void setCourseId(String courseId) {
		this.courseId = courseId;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public String getNoOfDays() {
		return noOfDays;
	}

	public void setNoOfDays(String noOfDays) {
		this.noOfDays = noOfDays;
	}

	public String getFacultyId() {
		return facultyId;
	}

	public void setFacultyId(String facultyId) {
		this.facultyId = facultyId;
	}

	public String getFacultySkill() {
		return facultySkill;
	}

	public void setFacultySkill(String facultySkill) {
		this.facultySkill = facultySkill;
	}

	@Override
	public String toString() {
		return "CourseFacultyMapBean [courseId=" + courseId + ", courseName="
				+ courseName + ", noOfDays=" + noOfDays + ", facultyId="
				+ facultyId + ", facultySkill=" + facultySkill + "]";
	}

}
