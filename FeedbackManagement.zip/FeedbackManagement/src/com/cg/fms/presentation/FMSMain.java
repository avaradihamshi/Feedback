package com.cg.fms.presentation;

import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.CourseFacultyMapBean;
import com.cg.fms.model.CourseMasterBean;
import com.cg.fms.model.FacultySkillMasterBean;
import com.cg.fms.model.LoginBean;
import com.cg.fms.model.TrainingProgramMaintain;
import com.cg.fms.model.feedbackBean;
import com.cg.fms.model.participantEnroll;
import com.cg.fms.model.viewFeedbackMaster;
import com.cg.fms.service.FeedbackServiceIMPL;
import com.cg.fms.service.IFeedbackService;

public class FMSMain {
	static Logger logger = Logger.getLogger(FMSMain.class);
	static Scanner scanner = new Scanner(System.in);
	static IFeedbackService service;

	public static void main(String[] args) {
		PropertyConfigurator.configure("resources/log4j.properties");
		logger.info("log4j configured....");

		service = new FeedbackServiceIMPL();
		System.out.println("________________________________");
		System.out.println("------Feedback ------");
		System.out.println("_________________________________");
		System.out.println("Enter the user name");
		Scanner scanner = new Scanner(System.in);
		String username = scanner.nextLine();
		
		System.out.println("Enter the password");
		String password = scanner.nextLine();
		LoginBean login = new LoginBean();
		login.setPassword(password);
		login.setUsername(username);
		logger.info(login);
		try {
			String role = service.checkRole(login);
			String participantId=service.getParticipantId(login);
			
			
			if (role != null) {
				if (role.equalsIgnoreCase("admin")) {
					logger.info("admin is login");
					System.out.println("welcome to the admin page");
					adminPage();

				} else if (role.equalsIgnoreCase("coordinator")) {
					logger.info("co-ordinator is login");
					System.out.println("welcome to the coordinator page");
					coordinatorPage();
				} else if (role.equalsIgnoreCase("participant")) {
					logger.info("participant is login");
					System.out.println("welcome to the participant page");
					System.out.println("your particiapant id is"+participantId);
					participantPage(participantId);
				} else {
					System.out
							.println("please login properly,you are not a admin, coordinator and participant ");
					logger.info("please login properly,you are not a admin, coordinator and participant");
				}
			} else {
				System.out
						.println("please enter a valid user name and password");
				logger.info("please enter a valid user name and password");
			}
		} catch (FMSException e) {

			System.out.println(e.getMessage());
			logger.error(e.getMessage());
		}

	}

	private static void participantPage(String participantId) {
		System.out.println("welcome to the participant page");
		feedbackEntryPage(participantId);

	}

	private static void feedbackEntryPage(String participantId) {
		System.out.println(" feedback entry page");
		System.out.println("Give your FeedBack for the Training Program Below");
		System.out.println("\n");
		System.out.println("************************Rating Terminology***********************");
		System.out.println("-----------------------------------------------------------------");
		System.out.println("5-Excellent: 'Ideal way of doing it'\n"+
						   "4-Good: 'No pain areas or concern but could have been better'\n"+
						   "3-Average: 'There are concerns but not significant'\n"+
						   "2-Below Average: 'Needs improvement and is salvageable'\n"+
						   "1-Poor: 'This way of doing things must change'");
		System.out.println("-----------------------------------------------------------------");
		
		System.out.println("Please enter the Training Code for which you have enrolled");
		
		String trainingCode = scanner.nextLine();
		try {
			boolean result=service.getTrainingCode(trainingCode);
			if(result)
			{
				/*System.out.println("Enter the participant Id");
				String participantId=scanner.nextLine();*/
				boolean result1 = service.checkParticipantId(participantId,trainingCode);
				if(result1)
				{
					System.out.println("enter the feedback details");
					System.out.println("Presentation and communication skills of faculty");
					String presComm = scanner.nextLine();
					System.out.println("Ability to clarify doubts and explain difficult points");
					String clrfyDbts = scanner.nextLine();
					System.out.println("Time management in completing the contents ");
					String timeMgmt = scanner.nextLine();
					System.out.println("Handout provided(Student Guide)");
					String handOut = scanner.nextLine();
					System.out.println("Hardware, software and network availability");
					String hwSwNtwrk = scanner.nextLine();
					System.out.println("Comments");
					String comments = scanner.nextLine();
					System.out.println("Suggestions");
					String suggestions = scanner.nextLine();
				
				feedbackBean fbBean = new feedbackBean(trainingCode,participantId,presComm,clrfyDbts,timeMgmt,handOut,hwSwNtwrk,comments,suggestions);
				logger.info("feedback details"+fbBean);
				int result2=service.insertFeedback(fbBean);
				if(result2!=0)
				{
					System.out.println("feedback is successfuly added");
					logger.info("feedback is successfuly added");
					
				}
				else
				{
					System.out.println("feedback is not added successfully");
					logger.info("feedback is successfuly added");
				}
				}
				
				else
				{
				 System.out.println("Sorry your not the participant of the "+trainingCode+ "training program");	
				 logger.info("Sorry your not the participant of the "+trainingCode+ "training program");	
				}
			}
			else
			{
				System.out.println("selected Training code is not available");
				logger.info("selected Training code is not available");
			}
			
			
		} catch (FMSException e) {
logger.error(e.getMessage());
           System.out.println(e.getMessage());
		}
		
	}

	private static void coordinatorPage() {
		System.out.println("1.training program maintenance");
		System.out.println("2.participant enrollement");
		System.out.println("3.view feedback");

		System.out.println("enter your choice");
		int choice = scanner.nextInt();
		logger.info("in coordinator page selecting the option"+choice);

		switch (choice) {
		case 1:

			System.out
					.println("welcome to the training Program maintainance page");
			
			
			try {
				List<TrainingProgramMaintain> list=service.fetchingTrainingProgramDetails();
				if(list!=null)
				{
					System.out.println("tarainingcode participantId courseId courseName noDays facultyId skillSet startDate endDate");
					for (TrainingProgramMaintain trainingProgramMaintain : list) 
					{
						System.out.println(trainingProgramMaintain.getTrainingCode()+" "+trainingProgramMaintain.getParticipantId()+" "+trainingProgramMaintain.getCourseId()+" "+trainingProgramMaintain.getCourseName()+" "+trainingProgramMaintain.getNoDays()+" "+trainingProgramMaintain.getFacultId()+" "+trainingProgramMaintain.getSkillSet()+" "+trainingProgramMaintain.getStartDate()+" "+trainingProgramMaintain.getEndDate());
					}
				}
				else
				{
					System.out.println("no records");
				}
			} catch (FMSException e) {
				logger.error(e.getMessage());
				System.out.println(e.getMessage());
			}
			
			

			break;
		case 2:
			System.out.println("welcome to the participant enrollment page");
			scanner.nextLine();
			System.out.println("enter the training code");
			String trainingCode=scanner.nextLine();
			System.out.println("enter the participantId to enrolling");
			String participantId=scanner.nextLine();
			participantEnroll penroll=new participantEnroll(trainingCode,participantId);
			try {
				int result4=service.insertParticipant(penroll);
				if(result4!=0)
				{
					System.out.println("enrolling successful");
				}
				else
				{
					System.out.println("enrolling is not successful");
				}
			} catch (FMSException e) {
				logger.error(e.getMessage());
				System.out.println(e.getMessage());
			}
			
			
			

			break;
		case 3:

			System.out.println("welcome to the view feedback page");
		

			List<viewFeedbackMaster> list;
			try {
				list = service.viewAllFeedbackDetails();
				if (list != null)
				{
					System.out.println("trainingCode"+" "+"partipantId"+" "+"preAndcomm"+" "+"clarifyDoubts"+" "+"timeManegement"+" "+"handword provided"+" "+" hardware,software,netwokAvalablity"+" "+" comments"+" "+"suggestions" );
					for (viewFeedbackMaster viewFeedbackMaster : list) {
						System.out.println(viewFeedbackMaster.getTariningCode()+"  \t"+viewFeedbackMaster.getParticipantId()+"  \t"+viewFeedbackMaster.getFbPrsComm()+"  \t"+viewFeedbackMaster.getFbClrfyDbts()+"  \t"+viewFeedbackMaster.getFbTm()+"  \t"+viewFeedbackMaster.getFbHndOut()+"  \t"+viewFeedbackMaster.getFbHwSwNtwrk()+"  \t"+viewFeedbackMaster.getComments()+"  \t"+viewFeedbackMaster.getSuggestions());
						
					}
				}
				 else {
						System.out.println("no records found");
					}
			} catch (FMSException e) {
				logger.error(e.getMessage());
				System.out.println(e.getMessage());
			}

			break;
		}

	}

	private static void adminPage() {

		System.out.println("1.faculty skill maintanance");
		System.out.println("2.course maintanance");
		System.out.println("3.view feedback ");

		System.out.println("enter your choice");
		int choice = scanner.nextInt();

		switch (choice) {
		case 1:

			System.out
					.println("welcome to the faculty skill maintainance page");
			System.out.println("Enter the option you want to perform");
			System.out.println("1.Insert Faculty Details");
			System.out.println("2.Update Faculty Details");
			System.out.println("3.Delete Faculty Details");
			System.out.println("4.View Faculty Details");
			/*
			 * System.out.println("5.Insert Course Details ");
			 * System.out.println("6.Update Course Details ");
			 * System.out.println("7 Delete Course Details");
			 * System.out.println("8.View Course Details");
			 */
			System.out.println("5.view the mapping details of  faculties based on skill");
			System.out.println("6.Exit");
			int option = scanner.nextInt();
			switch (option) {
			case 1:
				System.out.println("Enter faculty details");
				FacultySkillMasterBean facultySkill = createFacultySkill();
				try {
					int insRes = service.insertFacultySkill(facultySkill);
					if (insRes != 0) {

						System.out
								.println("successfully inserted into faculty skill master ");
					} else {
						System.out
								.println("error while inserting  into faculty skill master");
					}
				} catch (FMSException e) {
					logger.error(e.getMessage());
					System.out.println(e.getMessage());
				}

				break;
			case 2:
				System.out.println("Enter faculty details to update");
				FacultySkillMasterBean facultyupdateSkill = updateFacultySkill();
				try {
					int updateres = service
							.updateFacultySkillOper(facultyupdateSkill);
					if (updateres != 0) {
						System.out.println("updated successful with id"
								+ facultyupdateSkill.getFacultyId());
					} else {
						System.out.println("unsuccessful update");
					}

				} catch (FMSException e) {
					logger.error(e.getMessage());
					System.out.println(e.getMessage());
				}

				break;
			case 3:
				System.out.println("delete faculty details");

				FacultySkillMasterBean facultydeleteSkill = deleteFacultySkill();
				try {
					int deleteres = service
							.deletefacultySkilloper(facultydeleteSkill
									.getFacultyId());

					if (deleteres != 0) {
						System.out.println("deleteed successful with id"
								+ facultydeleteSkill.getFacultyId());

					} else {
						System.out.println("delete unsuccessful");
					}
				} catch (FMSException e) {
					logger.error(e.getMessage());
					System.out.println(e.getMessage());
				}

				break;
			case 4:
				System.out.println("view faculty details");

				try {
					List<FacultySkillMasterBean> list = service
							.viewAllFacultyDetails();

					if (list != null) {
						System.out.println(" facultyId facultySkill");
						for (FacultySkillMasterBean facultySkillMasterBean : list) {
							System.out.println(facultySkillMasterBean
									.getFacultyId()
									+ " \t "
									+ facultySkillMasterBean
											.getFacultySkillSet());

						}
					} else {
						System.out.println("no records found");
					}

				} catch (FMSException e) {
					logger.error(e.getMessage());
					System.out.println(e.getMessage());
				}
				break;
			case 5:
				System.out
						.println("diplaying the mapping of faculty and course details");
				try {
					List<CourseFacultyMapBean> list = service.viewMapDetails();
					if (list != null) {
						System.out
								.println("courseId courseName noOfDays facultyId facultyName");
						for (CourseFacultyMapBean courseFacultyMapBean : list) {
							System.out.println(courseFacultyMapBean
									.getCourseId()
									+ " "
									+ courseFacultyMapBean.getCourseName()
									+ " "
									+ courseFacultyMapBean.getNoOfDays()
									+ " "
									+ courseFacultyMapBean.getFacultyId()
									+ " "
									+ courseFacultyMapBean.getFacultySkill());

						}

					} else {
						System.out.println("mapping is not available");
					}
				} catch (FMSException e) {
					logger.error(e.getMessage());
					System.out.println(e.getMessage());
				}
				break;

			case 6: 
				System.out.println("Exit");
				System.exit(0);
				break;
			}
		

			break;
		case 2:
			System.out.println("welcome to the course maintainance page");

			System.out.println("Enter the option you want to perform");
			System.out.println("1.Insert Course Details ");
			System.out.println("2.Update Course Details ");
			System.out.println("3. Delete Course Details");
			System.out.println("4.View Course Details");
			int option1 = scanner.nextInt();
			switch (option1) {
			case 1:
				System.out.println("Enter Course details");
				CourseMasterBean courseBean = createCourse();
				try {
					int insRes = service.insertCourseDetails(courseBean);
					if (insRes != 0) {

						System.out
								.println("successfully inserted into course master ");
					} else {
						System.out
								.println("error while inserting  into course master");
					}
				} catch (FMSException e) {
					logger.error(e.getMessage());
					System.out.println(e.getMessage());
				}

				break;
			case 2:
				System.out.println("Enter course details to update");
				CourseMasterBean courseBean1 = updateCourseDetails();
				try {
					int updateres = service.updateCourseOper(courseBean1);
					if (updateres != 0) {
						System.out.println("updated successful with id"
								+ courseBean1.getCourseId());
					} else {
						System.out.println("unsuccessful update");
					}

				} catch (FMSException e) {
					logger.error(e.getMessage());
					System.out.println(e.getMessage());
				}

				break;
			case 3:
				System.out.println("delete course details");

				CourseMasterBean courseBean2 = deleteCourseDetails();
			
				int deleteres;
				try {
					deleteres = service.deleteCourseoper(courseBean2
							.getCourseId());
					if (deleteres != 0) {
						System.out.println("deleted successful with id "
								+ courseBean2.getCourseId());

					} else {
						System.out.println("delete unsuccessful");
					}
				} catch (FMSException e) {
					logger.error(e.getMessage());
					System.out.println(e.getMessage());
				}

				

				break;
			case 4:
				System.out.println("view course details");
				try {
					List<CourseMasterBean> list = service
							.viewAllCourseDetails();

					if (list != null) {
						System.out.println("courseID"+" "+"courseName"+" "+"noOfDays" );
						for (CourseMasterBean courseMasterBean : list) {
							System.out.println(courseMasterBean.getCourseId()
									+ " \t " + courseMasterBean.getCourseName()
									+ "  \t" + courseMasterBean.getNoOfDays());

						}
					} else {
						System.out.println("no records found");
					}

				} catch (FMSException e) {
					logger.error(e.getMessage());
					System.out.println(e.getMessage());
				}

				break;

			}

			break;
		case 3:
			System.out.println("welcome to the view feedback page");

			List<viewFeedbackMaster> list;
			try {
				list = service.viewAllFeedbackDetails();
				if (list != null)
				{
					System.out.println("trainingCode"+" "+"partipantId"+" "+"preAndcomm"+" "+"clarifyDoubts"+" "+"timeManegement"+" "+"handword provided"+" "+" hardware,software,netwokAvalablity"+" "+" comments"+" "+"suggestions" );
					for (viewFeedbackMaster viewFeedbackMaster : list) {
						System.out.println(viewFeedbackMaster.getTariningCode()+"  \t"+viewFeedbackMaster.getParticipantId()+"  \t"+viewFeedbackMaster.getFbPrsComm()+"  \t"+viewFeedbackMaster.getFbClrfyDbts()+"  \t"+viewFeedbackMaster.getFbTm()+"  \t"+viewFeedbackMaster.getFbHndOut()+"  \t"+viewFeedbackMaster.getFbHwSwNtwrk()+"  \t"+viewFeedbackMaster.getComments()+"  \t"+viewFeedbackMaster.getSuggestions());
						
					}
				}
				 else {
						System.out.println("no records found");
					}
			} catch (FMSException e) {
				logger.error(e.getMessage());
				System.out.println(e.getMessage());
			}
			
			
			
			
			break;
		}
	}

	private static CourseMasterBean deleteCourseDetails() {
		scanner.nextLine();
		System.out.println("enter the id to delete");
		String courseId = scanner.nextLine();
		CourseMasterBean course2 = new CourseMasterBean(courseId);
		return course2;
	}

	private static CourseMasterBean updateCourseDetails() {
		scanner.nextLine();
		System.out.println("enter the course id to update table");
		String courseId = scanner.nextLine();
		System.out.println("enter the course name you want to update");
		String courseName = scanner.nextLine();
		System.out.println("enter the no of days");
		String noOfDays = scanner.nextLine();

		CourseMasterBean course1 = new CourseMasterBean(courseId, courseName,
				noOfDays);
		return course1;
	}

	private static CourseMasterBean createCourse() {
		scanner.nextLine();
		System.out.println("enter the courseId");
		String courseId = scanner.nextLine();
		System.out.println("enter the course name");
		String courseName = scanner.nextLine();
		System.out.println("enter the no of days");
		String noOfDays = scanner.nextLine();
		CourseMasterBean courbean = new CourseMasterBean(courseId, courseName,
				noOfDays);

		return courbean;
	}

	private static FacultySkillMasterBean deleteFacultySkill() {
		scanner.nextLine();
		System.out.println("enter the id to delete");
		String facultId = scanner.nextLine();
		FacultySkillMasterBean faculty2 = new FacultySkillMasterBean(facultId);
		return faculty2;

	}

	private static FacultySkillMasterBean updateFacultySkill() {
		scanner.nextLine();
		System.out.println("enter the faculty id to update the skill");
		String fcaultyId = scanner.nextLine();
		System.out.println("enter the skill you want to update");
		String skill = scanner.nextLine();

		FacultySkillMasterBean faculty1 = new FacultySkillMasterBean(fcaultyId,
				skill);
		return faculty1;
	}

	private static FacultySkillMasterBean createFacultySkill() {
		scanner.nextLine();
		System.out
				.println("Enter the Faculty Id start with 2000 it cannot be duplicate");
		String facultyId = scanner.nextLine();
		System.out.println("Enter the Faculty Skill");
		String facultySkill = scanner.nextLine();

		FacultySkillMasterBean faculty = new FacultySkillMasterBean(facultyId,
				facultySkill);
		return faculty;
	}

}
